#pragma once
#ifndef __MOUSE_BUTTONS__
#define __MOUSE_BUTTONS__
enum MouseButtons
{
    LEFT,
    MIDDLE,
    RIGHT
};

#endif /* defined (__MOUSE_BUTTONS__) */
