#pragma once
#ifndef __HEURISTIC__
#define __HEURISTIC__
enum Heuristic
{
	MANHATTAN,
	EUCLIDEAN,
	NUM_OF_HEURISTICS
};
#endif /* defined (__HEURISTIC__) */