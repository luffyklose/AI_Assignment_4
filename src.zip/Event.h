#pragma once
#ifndef __EVENT__
#define __EVENT__

enum Event
{
	CLICK,
	MOUSE_OVER,
	MOUSE_OUT,
	NUM_OF_EVENTS
};

#endif /* defined (__EVENT__) */