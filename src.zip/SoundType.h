#pragma once
#ifndef __SOUND_TYPE__
#define __SOUND_TYPE__

enum SoundType
{
	SOUND_MUSIC = 0,
	SOUND_SFX = 1,
	NUM_OF_SOUND_TYPES
};

#endif /* defined (__SOUND_TYPE__) */