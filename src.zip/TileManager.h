﻿#pragma once
#include "Tile.h"

class TileManager
{
public:
	
};
